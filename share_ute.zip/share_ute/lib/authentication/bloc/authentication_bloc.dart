import 'dart:async';

import 'package:authentication_repository/authentication_repository.dart';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:pedantic/pedantic.dart';

part 'authentication_event.dart';

part 'authentication_state.dart';

// The AuthenticationBloc is responsible for managing the authentication state
// for application. It has a dependency on the AuthenticationRepository and
// subscribes to the user Stream in order to emit new states in response to
// changes in the current user

// The AuthenticationBloc responds to incoming AuthenticationEvents and transforms
// them into outgoing AuthenticationStates. Upon initialization, it immediately
// subscribes to the user Stream from the AuthenticationRepository and adds an
// AuthenticationUserChanged event internally to process changes in the current
// user
class AuthenticationBloc
    extends Bloc<AuthenticationEvent, AuthenticationState> {
  AuthenticationBloc({
    @required AuthenticationRepository authenticationRepository,
  })  : assert(authenticationRepository != null),
        _authenticationRepository = authenticationRepository,
        super(const AuthenticationState.unknown()) {
    _userSubscription = _authenticationRepository.user.listen(
      (user) => add(AuthenticationUserChanged(user)),
    );
  }

  final AuthenticationRepository _authenticationRepository;

  StreamSubscription<User> _userSubscription;

  @override
  Stream<AuthenticationState> mapEventToState(AuthenticationEvent event) async*{
    if(event is AuthenticationUserChanged){
      yield _mapAuthenticationUserChangedToState(event);
    }else if (event is AuthenticationLogoutRequested){
      unawaited(_authenticationRepository.logOut());
    }
  }

  @override
  Future<void> close() {
    _userSubscription?.cancel();
    return super.close();
  }

  AuthenticationState _mapAuthenticationUserChangedToState(
    AuthenticationUserChanged event,
  ) {
    return event.user != User.empty
        ? AuthenticationState.authenticated(event.user)
        : const AuthenticationState.unauthenticated();
  }
}
