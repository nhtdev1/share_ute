import 'package:flutter/cupertino.dart';

class SelectableMajorWidget extends StatefulWidget {
  @override
  _SelectableMajorWidgetState createState() => _SelectableMajorWidgetState();
}

class _SelectableMajorWidgetState extends State<SelectableMajorWidget> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
