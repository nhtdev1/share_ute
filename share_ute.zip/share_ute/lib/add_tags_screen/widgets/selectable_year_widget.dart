import 'package:flutter/cupertino.dart';

class SelectableYearWidget extends StatefulWidget {
  @override
  _SelectableYearWidgetState createState() => _SelectableYearWidgetState();
}

class _SelectableYearWidgetState extends State<SelectableYearWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
