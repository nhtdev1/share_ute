class Post{
  final String fileType;

  final String fileName;

  final String fileImage;

  DateTime dateCreated;

  Post({
    this.fileType,
    this.fileName,
    this.fileImage,
    this.dateCreated});
}