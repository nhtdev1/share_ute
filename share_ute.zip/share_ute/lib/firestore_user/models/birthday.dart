class Birthday {
  const Birthday({this.date});

  final String date;
}
