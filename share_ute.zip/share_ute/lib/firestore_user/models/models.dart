export 'name.dart';
export 'birthday.dart';
export 'mobile.dart';
export 'year.dart';
export 'faculty.dart';
export 'major.dart';
export 'hobbies.dart';