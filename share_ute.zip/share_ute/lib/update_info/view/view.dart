export 'update_info_form.dart';
export 'update_info_page.dart';