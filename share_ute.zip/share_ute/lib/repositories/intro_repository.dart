class IntroRepository {
  List<String> getMajors(){
    List<String> result = new List<String>();
    result.add("Bán Kem Trộn");
    result.add("Game Thủ");
    result.add("Fuck Boy");
    result.add("Công Nghệ Thông Tin");
    result.add("Cơ Khí Chế Tạo Máy");
    result.add("Quản Trị Kinh Doanh");
    result.add("Công Nghệ May & Thời Trang");
    result.add("Xây Dựng");
    result.add("Kĩ Thuật In");
    result.add("Logistics");
    result.add("Ô tô");
    result.add("Điện - Điện Tử");
    result.add("Trí Tuệ Nhân Tạo");
    result.add("Quản Trị Nhà Hàng Và Dịch Vụ Ăn Uống");
    return result;
  }

  List<String> getSubject(){
    List<String> result = new List<String>();
    result.add("Toán 1");
    result.add("Toán 2");
    result.add("Toán 3");
    result.add("Toán Rời Rạc & Lí Thuyết Đồ Thị");
    result.add("Xác Suất Thống Kê");
    result.add("Mác - Lênin");
    result.add("Mạng Máy Tính");
    result.add("Bảo Mật Website");
    result.add("Vi Xử Lí");
    result.add("Điện Căn Bản");
    result.add("Ô tô");
    result.add("Lập Trình Nhúng");
    result.add("Vật Lí 1");
    result.add("Vật Lí 2");
    return result;
  }

}
