import 'package:formz/formz.dart';

enum LecturersValidationError { invalid }

class Lecturers extends FormzInput<String, LecturersValidationError> {
  const Lecturers.pure([String value = '']) : super.pure(value);

  const Lecturers.dirty([String value = '']) : super.dirty(value);

  static final RegExp _lecturersRegExp = RegExp(
      r'^[a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶ'
      r'ẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪ'
      r'ễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]{2,30}'
      r'(?: [a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶ'
      r'ẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪ'
      r'ễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]+){0,3}$');

  @override
  LecturersValidationError validator(String value) {
    return _lecturersRegExp.hasMatch(value)
        ? null
        : LecturersValidationError.invalid;
  }

  bool get isNotEmpty => value.trim() != '';
}
