library storage_repository;

export 'src/storage_repository.dart';